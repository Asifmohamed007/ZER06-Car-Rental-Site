import { readFileSync } from "fs";
import postgres from "postgres";

export const TEST_URL = process.env.TEST_DATABASE_URL ?? "postgres://zero6:devpass@localhost:5432/zero6_test";
process.env.DATABASE_URL = TEST_URL;
process.env.DATABASE_SSL = "false";
process.env.DATABASE_POOL_MAX = "25";

/** Recreates the schema from the real migration file. Never point TEST_DATABASE_URL at production. */
export async function resetDb() {
  if (!/test/.test(TEST_URL)) throw new Error("Refusing to reset a database whose name doesn't contain 'test'");
  const sql = postgres(TEST_URL, { max: 1, onnotice: () => {} });
  await sql.unsafe("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  await sql.unsafe(readFileSync("migrations/001_init.sql", "utf8"));
  const [{ id }] = await sql<{ id: string }[]>`
    INSERT INTO vehicles (slug, brand, model, year, category, transmission, seats, daily_rate, deposit)
    VALUES ('test-car', 'Toyota', 'Camry', 2024, 'sedan', 'automatic', 5, 200, 1000) RETURNING id`;
  await sql`INSERT INTO vehicles (slug, brand, model, year, category, transmission, seats, daily_rate, is_available) VALUES ('paused-car', 'Honda', 'City', 2023, 'sedan', 'manual', 5, 100, false)`;
  await sql.end();
  return Number(id);
}
