import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { randomUUID } from "crypto";
import { resetDb } from "./setup";
import { createBooking, quoteBooking, changeBookingStatus, getBookingForCustomer, busyIntervals, addBlocked, busyVehicleIds } from "@/server/bookings";
import { rateLimit } from "@/server/rate-limit";
import { sql } from "@/server/db";
import { defaultSettings } from "@/lib/settings-schema";
import type { BookingRequest } from "@/lib/validation";

const settings = structuredClone(defaultSettings);
settings.booking.locations = [{ id: "office", name: "Office", fee: 0 }, { id: "airport", name: "Airport", fee: 75 }];
let vehicleId = 0;

// Fixed "now" so tests don't depend on the real date: 14 Oct 2026, 09:00 in Doha.
const NOW = new Date("2026-10-14T06:00:00Z");

const req = (over: Partial<BookingRequest> = {}): BookingRequest => ({
  vehicleSlug: "test-car", pickupDate: "2026-11-10", pickupTime: "10:00", returnDate: "2026-11-12", returnTime: "10:00",
  pickupLocation: "office", returnLocation: "office", additionalDriver: false, idempotencyKey: randomUUID(),
  customerName: "Test Customer", customerPhone: "+974 5555 0000", customerEmail: "test@example.com", driverAge: 30,
  notes: "", paymentMethod: "pay_on_arrival", acceptPolicies: true, ...over,
});

beforeAll(async () => { vehicleId = await resetDb(); });
afterAll(async () => { await sql().end(); });

describe("booking workflow (real PostgreSQL)", () => {
  it("quotes from database price, not client input", async () => {
    const q = await quoteBooking({ ...req(), pickupLocation: "airport" }, settings, sql(), NOW);
    expect(q.ok && q.quote.total).toBe(2 * 200 + 75);
    expect(q.ok && q.available).toBe(true);
  });

  it("creates a pending booking with a reference and a private access link", async () => {
    const r = await createBooking(req({ idempotencyKey: "11111111-1111-4111-8111-111111111111" }), settings, NOW);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.status).toBe("pending");
    expect(r.reference).toMatch(/^Z6-/);
    const view = await getBookingForCustomer(r.reference, "11111111-1111-4111-8111-111111111111");
    expect(view?.total).toBe(400);
    expect(await getBookingForCustomer(r.reference, randomUUID())).toBeNull(); // wrong token
  });

  it("returns the same booking for a duplicate submission", async () => {
    const r = await createBooking(req({ idempotencyKey: "11111111-1111-4111-8111-111111111111" }), settings, NOW);
    expect(r.ok && r.duplicate).toBe(true);
    const [{ n }] = await sql()<{ n: string }[]>`SELECT count(*) n FROM bookings`;
    expect(Number(n)).toBe(1);
  });

  it("rejects an overlapping booking", async () => {
    const r = await createBooking(req({ pickupDate: "2026-11-11", returnDate: "2026-11-13" }), settings, NOW);
    expect(r).toMatchObject({ ok: false, status: 409 });
  });

  it("allows back-to-back bookings (return time = next pickup time)", async () => {
    const r = await createBooking(req({ pickupDate: "2026-11-12", returnDate: "2026-11-13" }), settings, NOW);
    expect(r.ok).toBe(true);
  });

  it("prevents double-booking under 20 simultaneous requests", async () => {
    const attempts = await Promise.all(Array.from({ length: 20 }, () => createBooking(req({ pickupDate: "2026-12-01", returnDate: "2026-12-03" }), settings, NOW)));
    const ok = attempts.filter((a) => a.ok);
    expect(ok).toHaveLength(1);
    expect(attempts.filter((a) => !a.ok && a.status === 409)).toHaveLength(19);
  });

  it("database constraint blocks overlaps even if application checks are bypassed", async () => {
    await expect(sql()`
      INSERT INTO bookings (reference, idempotency_key, vehicle_id, customer_name, customer_phone, customer_email, pickup_at, return_at, pickup_location, return_location, billable_days, daily_rate, price_breakdown, total, payment_method)
      VALUES ('Z6-RAWTEST', 'raw', ${vehicleId}, 'x', 'x', 'x', '2026-12-02T00:00:00Z', '2026-12-04T00:00:00Z', 'Office', 'Office', 2, 200, '{}', 400, 'pay_on_arrival')`)
      .rejects.toMatchObject({ code: "23P01" });
  });

  it("frees the dates when a booking is cancelled", async () => {
    const r = await createBooking(req({ pickupDate: "2027-01-05", returnDate: "2027-01-06" }), settings, NOW);
    expect(r.ok).toBe(true);
    const [{ id }] = await sql()<{ id: string }[]>`SELECT id FROM bookings WHERE reference = ${r.ok ? r.reference : ""}`;
    expect(await changeBookingStatus(Number(id), "cancelled")).toEqual({ ok: true });
    expect((await createBooking(req({ pickupDate: "2027-01-05", returnDate: "2027-01-06" }), settings, NOW)).ok).toBe(true);
  });

  it("enforces status transitions", async () => {
    const r = await createBooking(req({ pickupDate: "2027-02-01", returnDate: "2027-02-02" }), settings, NOW);
    const [{ id }] = await sql()<{ id: string }[]>`SELECT id FROM bookings WHERE reference = ${r.ok ? r.reference : ""}`;
    expect((await changeBookingStatus(Number(id), "completed")).ok).toBe(false); // pending -> completed not allowed
    expect((await changeBookingStatus(Number(id), "confirmed")).ok).toBe(true);
    expect((await changeBookingStatus(Number(id), "completed")).ok).toBe(true);
    expect((await changeBookingStatus(Number(id), "cancelled")).ok).toBe(false); // completed is final
  });

  it("blocks dates set by the admin", async () => {
    await addBlocked(vehicleId, new Date("2027-03-01T00:00:00Z"), new Date("2027-03-05T00:00:00Z"), "service");
    const r = await createBooking(req({ pickupDate: "2027-03-03", returnDate: "2027-03-07" }), settings, NOW);
    expect(r).toMatchObject({ ok: false, status: 409 });
    expect((await busyVehicleIds(new Date("2027-03-02T00:00:00Z"), new Date("2027-03-03T00:00:00Z"))).has(vehicleId)).toBe(true);
    const busy = await busyIntervals(vehicleId, new Date("2027-02-25T00:00:00Z"), new Date("2027-03-10T00:00:00Z"));
    expect(busy.length).toBeGreaterThan(0);
    expect(Object.keys(busy[0])).toEqual(["start", "end"]); // no customer data
  });

  it("rejects unavailable, archived and unknown cars", async () => {
    expect(await createBooking(req({ vehicleSlug: "paused-car" }), settings, NOW)).toMatchObject({ ok: false, status: 409 });
    expect(await createBooking(req({ vehicleSlug: "no-such-car" }), settings, NOW)).toMatchObject({ ok: false, status: 404 });
    await sql()`UPDATE vehicles SET archived_at = now() WHERE slug = 'paused-car'`;
    expect(await createBooking(req({ vehicleSlug: "paused-car" }), settings, NOW)).toMatchObject({ ok: false, status: 404 });
  });

  it("rejects invalid windows, unknown locations and underage drivers", async () => {
    expect(await createBooking(req({ returnDate: "2026-11-09" }), settings, NOW)).toMatchObject({ ok: false, field: "returnDate" });
    expect(await createBooking(req({ pickupDate: "2026-10-01" }), settings, NOW)).toMatchObject({ ok: false, field: "pickupDate" });
    expect(await createBooking(req({ pickupLocation: "mars" }), settings, NOW)).toMatchObject({ ok: false, field: "pickupLocation" });
    expect(await createBooking(req({ driverAge: 18 }), settings, NOW)).toMatchObject({ ok: false, field: "driverAge" });
  });

  it("auto-confirms when approval is turned off", async () => {
    const r = await createBooking(req({ pickupDate: "2027-04-01", returnDate: "2027-04-02" }), { ...settings, booking: { ...settings.booking, requireApproval: false } }, NOW);
    expect(r.ok && r.status).toBe("confirmed");
  });
});

describe("rate limiting", () => {
  it("blocks after the limit within the window", async () => {
    const results = [];
    for (let i = 0; i < 4; i++) results.push((await rateLimit("test:key", 3, 60)).ok);
    expect(results).toEqual([true, true, true, false]);
  });
});
