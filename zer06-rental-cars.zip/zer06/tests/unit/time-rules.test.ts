import { describe, it, expect } from "vitest";
import { zonedToUtc, dateKeyInZone, addDaysToKey, defaultWindow } from "@/lib/time";
import { checkRentalWindow } from "@/lib/booking-rules";

describe("timezone conversion (Asia/Qatar, UTC+3)", () => {
  it("converts wall-clock to UTC", () => expect(zonedToUtc("2026-11-01", "10:00", "Asia/Qatar")!.toISOString()).toBe("2026-11-01T07:00:00.000Z"));
  it("handles midnight crossing", () => expect(zonedToUtc("2026-11-01", "01:30", "Asia/Qatar")!.toISOString()).toBe("2026-10-31T22:30:00.000Z"));
  it("rejects invalid dates", () => { expect(zonedToUtc("2026-02-30", "10:00", "Asia/Qatar")).toBeNull(); expect(zonedToUtc("2026-01-01", "24:00", "Asia/Qatar")).toBeNull(); expect(zonedToUtc("nope", "10:00", "Asia/Qatar")).toBeNull(); });
  it("handles a DST zone", () => expect(zonedToUtc("2026-07-01", "12:00", "Europe/London")!.toISOString()).toBe("2026-07-01T11:00:00.000Z"));
  it("gets local date keys", () => expect(dateKeyInZone(new Date("2026-10-31T22:30:00Z"), "Asia/Qatar")).toBe("2026-11-01"));
  it("adds days across months", () => expect(addDaysToKey("2026-12-31", 1)).toBe("2027-01-01"));
  it("default window is tomorrow to the day after", () => {
    const w = defaultWindow("Asia/Qatar", new Date("2026-10-14T22:00:00Z")); // 01:00 on the 15th in Doha
    expect(w).toMatchObject({ today: "2026-10-15", pickupDate: "2026-10-16", returnDate: "2026-10-17" });
  });
});

describe("checkRentalWindow", () => {
  const policy = { graceMinutes: 60, minDays: 1, maxDays: 30, minLeadHours: 2, maxAdvanceDays: 365 };
  const now = new Date("2026-10-14T06:00:00Z"); // 09:00 Doha
  const w = (pd: string, pt: string, rd: string, rt: string) => checkRentalWindow({ pickupDate: pd, pickupTime: pt, returnDate: rd, returnTime: rt }, "Asia/Qatar", policy, now);
  it("accepts a valid window", () => expect(w("2026-10-15", "10:00", "2026-10-17", "10:00").ok).toBe(true));
  it("rejects return before pickup", () => expect(w("2026-10-15", "10:00", "2026-10-15", "09:00")).toMatchObject({ ok: false, field: "returnDate" }));
  it("rejects return equal to pickup", () => expect(w("2026-10-15", "10:00", "2026-10-15", "10:00").ok).toBe(false));
  it("rejects past pickup", () => expect(w("2026-10-13", "10:00", "2026-10-15", "10:00")).toMatchObject({ ok: false, field: "pickupDate" }));
  it("enforces lead time", () => expect(w("2026-10-14", "10:30", "2026-10-15", "10:00").ok).toBe(false));
  it("allows pickup right at lead time", () => expect(w("2026-10-14", "11:00", "2026-10-15", "10:00").ok).toBe(true));
  it("enforces max days", () => expect(w("2026-10-15", "10:00", "2026-12-15", "10:00").ok).toBe(false));
  it("enforces max advance", () => expect(w("2027-12-15", "10:00", "2027-12-16", "10:00").ok).toBe(false));
  it("rejects malformed input", () => expect(w("2026-13-01", "10:00", "2026-10-16", "10:00").ok).toBe(false));
});
