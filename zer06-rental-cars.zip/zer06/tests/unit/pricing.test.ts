import { describe, it, expect } from "vitest";
import { billableDays, computeQuote } from "@/lib/pricing";

const policy = { graceMinutes: 60, minDays: 1, additionalDriverPerDay: 50, taxPercent: 0 };
const at = (h: number, m = 0) => new Date(Date.UTC(2026, 10, 1, 0, 0) + (h * 60 + m) * 60_000);
const p0 = at(0);

describe("billableDays", () => {
  it("charges the minimum for short rentals", () => expect(billableDays(p0, at(3), policy)).toBe(1));
  it("charges 1 day for exactly 24h", () => expect(billableDays(p0, at(24), policy)).toBe(1));
  it("forgives the grace period", () => expect(billableDays(p0, at(25), policy)).toBe(1));
  it("charges a new day one minute after grace", () => expect(billableDays(p0, at(25, 1), policy)).toBe(2));
  it("handles multi-day rentals", () => expect(billableDays(p0, at(72), policy)).toBe(3));
  it("respects minDays", () => expect(billableDays(p0, at(5), { graceMinutes: 0, minDays: 3 })).toBe(3));
  it("works with zero grace", () => expect(billableDays(p0, at(24, 1), { graceMinutes: 0, minDays: 1 })).toBe(2));
  it("rejects return before pickup", () => expect(() => billableDays(at(5), at(4), policy)).toThrow());
  it("rejects equal times", () => expect(() => billableDays(p0, p0, policy)).toThrow());
});

describe("computeQuote", () => {
  const base = { pickupAt: p0, returnAt: at(48), dailyRate: 200, pickupFee: 0, returnFee: 0, pickupLocationName: "Office", returnLocationName: "Office", additionalDriver: false, deposit: 1000 };
  it("multiplies rate by days", () => {
    const q = computeQuote(base, policy);
    expect(q.billableDays).toBe(2);
    expect(q.total).toBe(400);
    expect(q.deposit).toBe(1000);
    expect(q.lines).toHaveLength(1);
  });
  it("adds location fees and extra driver", () => {
    const q = computeQuote({ ...base, pickupFee: 100, returnFee: 50, additionalDriver: true }, policy);
    expect(q.subtotal).toBe(400 + 100 + 50 + 100);
    expect(q.lines.map((l) => l.amount)).toEqual([400, 100, 50, 100]);
  });
  it("skips extra driver line when fee is zero", () => {
    expect(computeQuote({ ...base, additionalDriver: true }, { ...policy, additionalDriverPerDay: 0 }).lines).toHaveLength(1);
  });
  it("rounds tax to whole riyals", () => {
    const q = computeQuote({ ...base, dailyRate: 333 }, { ...policy, taxPercent: 5 });
    expect(q.subtotal).toBe(666);
    expect(q.tax).toBe(33);
    expect(q.total).toBe(699);
  });
});
