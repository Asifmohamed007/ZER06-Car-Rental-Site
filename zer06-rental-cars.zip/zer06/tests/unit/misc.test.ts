import { describe, it, expect } from "vitest";
import { buildWhatsAppMessage, whatsappLink } from "@/lib/whatsapp";
import { sniffImageType, validateUpload, MAX_UPLOAD_BYTES } from "@/lib/uploads";
import { bookingRequestSchema, enquirySchema, vehicleSchema } from "@/lib/validation";
import { parseBlocks, parseLocations, parsePairs, formatBlocks, formatLocations } from "@/lib/settings-form";
import { defaultSettings, mergeSettings, settingsSchema } from "@/lib/settings-schema";
import { generateReference } from "@/lib/reference";

describe("WhatsApp", () => {
  it("builds a message with all details", () => {
    const m = buildWhatsAppMessage({ businessName: "ZER06", vehicleName: "2024 Toyota Camry", pickup: "Thu 15 Oct, 10:00", return: "Sat 17 Oct, 10:00", location: "Airport", estimate: "QAR 360" });
    expect(m).toContain("Car: 2024 Toyota Camry");
    expect(m).toContain("Pickup: Thu 15 Oct, 10:00");
    expect(m).toContain("Estimated price: QAR 360");
  });
  it("omits missing fields", () => expect(buildWhatsAppMessage({ businessName: "Z" })).not.toContain("Car:"));
  it("URL-encodes text including & # + and newlines", () => {
    const link = whatsappLink("+974 0000 0000", "A & B #1 + 2\nnext")!;
    expect(link.startsWith("https://wa.me/97400000000?text=")).toBe(true);
    expect(decodeURIComponent(link.split("text=")[1])).toBe("A & B #1 + 2\nnext");
    expect(link).not.toMatch(/[ &#\n](?!.*text=)/);
  });
  it("returns null without a valid number", () => { expect(whatsappLink("")).toBeNull(); expect(whatsappLink("123")).toBeNull(); });
});

describe("upload validation", () => {
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]);
  const jpg = new Uint8Array([0xff, 0xd8, 0xff, 0xe0]);
  const webp = new TextEncoder().encode("RIFF\0\0\0\0WEBPVP8 ");
  it("detects real types", () => { expect(sniffImageType(png)).toBe("image/png"); expect(sniffImageType(jpg)).toBe("image/jpeg"); expect(sniffImageType(webp)).toBe("image/webp"); });
  it("rejects SVG/HTML/scripts disguised as images", () => {
    expect(validateUpload(new TextEncoder().encode("<svg onload=alert(1)>")).ok).toBe(false);
    expect(validateUpload(new TextEncoder().encode("<html>")).ok).toBe(false);
  });
  it("rejects empty and oversized files", () => {
    expect(validateUpload(new Uint8Array()).ok).toBe(false);
    const big = new Uint8Array(MAX_UPLOAD_BYTES + 1); big.set(jpg);
    expect(validateUpload(big).ok).toBe(false);
  });
});

describe("validation schemas", () => {
  const good = {
    vehicleSlug: "toyota-camry", pickupDate: "2026-11-01", pickupTime: "10:00", returnDate: "2026-11-03", returnTime: "10:00",
    pickupLocation: "office", returnLocation: "office", additionalDriver: false, idempotencyKey: "4b0f8a5e-2d7c-4f1a-9a39-5d7d2f6f1c11",
    customerName: "Sara Ali", customerPhone: "+974 5555 1234", customerEmail: "Sara@Example.com", driverAge: 30, notes: "",
    paymentMethod: "pay_on_arrival", acceptPolicies: true,
  };
  it("accepts a valid booking and normalises email", () => {
    const r = bookingRequestSchema.safeParse(good);
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.customerEmail).toBe("sara@example.com");
  });
  it("ignores client-submitted prices (unknown keys are stripped)", () => {
    const r = bookingRequestSchema.safeParse({ ...good, total: 1, dailyRate: 1 });
    expect(r.success && !("total" in r.data)).toBe(true);
  });
  it("rejects bad email, phone, unaccepted policies, filled honeypot", () => {
    expect(bookingRequestSchema.safeParse({ ...good, customerEmail: "x" }).success).toBe(false);
    expect(bookingRequestSchema.safeParse({ ...good, customerPhone: "abc" }).success).toBe(false);
    expect(bookingRequestSchema.safeParse({ ...good, acceptPolicies: false }).success).toBe(false);
    expect(bookingRequestSchema.safeParse({ ...good, website: "spam" }).success).toBe(false);
    expect(bookingRequestSchema.safeParse({ ...good, idempotencyKey: "123" }).success).toBe(false);
  });
  it("validates enquiries", () => {
    expect(enquirySchema.safeParse({ name: "Al", email: "a@b.co", message: "short" }).success).toBe(false);
    expect(enquirySchema.safeParse({ name: "Al", email: "a@b.co", message: "Is the Thar free on Friday?" }).success).toBe(true);
  });
  it("validates vehicles", () => {
    const v = { brand: "Toyota", model: "Camry", year: 2024, slug: "toyota-camry", category: "sedan", transmission: "automatic", seats: 5, dailyRate: 180, deposit: 0, isAvailable: true, isFeatured: false };
    expect(vehicleSchema.safeParse(v).success).toBe(true);
    expect(vehicleSchema.safeParse({ ...v, slug: "Bad Slug" }).success).toBe(false);
    expect(vehicleSchema.safeParse({ ...v, dailyRate: 10.5 }).success).toBe(false);
    expect(vehicleSchema.safeParse({ ...v, category: "spaceship" }).success).toBe(false);
  });
});

describe("settings", () => {
  it("defaults are valid", () => expect(settingsSchema.safeParse(defaultSettings).success).toBe(true));
  it("merges partial stored settings over defaults", () => {
    const s = mergeSettings({ business: { phone: "+974 1234" } });
    expect(s.business.phone).toBe("+974 1234");
    expect(s.business.email).toBe(defaultSettings.business.email);
  });
  it("falls back to defaults on invalid stored data", () => expect(mergeSettings({ booking: { minDays: -5 } }).booking.minDays).toBe(defaultSettings.booking.minDays));
  it("round-trips list editors", () => {
    expect(parseLocations(formatLocations(defaultSettings.booking.locations))).toEqual(defaultSettings.booking.locations);
    const faqs = defaultSettings.homepage.faqs.map((f) => ({ head: f.q, body: f.a }));
    expect(parseBlocks(formatBlocks(faqs))).toEqual(faqs);
    expect(parsePairs("Sat | 9 to 5\nFri | Closed")).toEqual([{ label: "Sat", value: "9 to 5" }, { label: "Fri", value: "Closed" }]);
  });
});

describe("references", () => {
  it("are unique-looking and unambiguous", () => {
    const refs = new Set(Array.from({ length: 2000 }, generateReference));
    expect(refs.size).toBe(2000);
    for (const r of refs) expect(r).toMatch(/^Z6-[A-HJ-KM-NP-Z2-9]{7}$/);
  });
});
