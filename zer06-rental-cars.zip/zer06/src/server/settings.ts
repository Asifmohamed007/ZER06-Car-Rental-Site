import "server-only";
import * as React from "react";
import { sql, isDbConnectionError } from "./db";
import { defaultSettings, mergeSettings, settingsSchema, type SiteSettings } from "@/lib/settings-schema";
import { logError } from "./log";

// React.cache dedupes per request inside Next; falls back to a plain function in scripts/tests.
const cache: <T extends (...a: never[]) => unknown>(fn: T) => T = (React as unknown as { cache?: <T>(fn: T) => T }).cache ?? ((fn) => fn);

export const getSettings = cache(async (): Promise<SiteSettings> => {
  try {
    const rows = await sql()<{ value: unknown }[]>`SELECT value FROM settings WHERE key = 'site'`;
    return mergeSettings(rows[0]?.value ?? {});
  } catch (e) {
    if (!isDbConnectionError(e)) logError("settings.load_failed", e);
    else logError("settings.db_unavailable", e);
    return defaultSettings; // site keeps rendering with defaults if the DB is briefly unavailable
  }
});

export async function saveSettings(input: unknown) {
  const parsed = settingsSchema.safeParse(input);
  if (!parsed.success) return { ok: false as const, error: parsed.error };
  const ids = parsed.data.booking.locations.map((l) => l.id);
  if (new Set(ids).size !== ids.length) {
    return { ok: false as const, message: "Each pickup location needs a unique ID." };
  }
  await sql()`
    INSERT INTO settings (key, value, updated_at) VALUES ('site', ${sql().json(parsed.data)}, now())
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`;
  return { ok: true as const, settings: parsed.data };
}
