import "server-only";
import { sql } from "./db";
import type { VehicleInput } from "@/lib/validation";

export type VehicleImage = { id: number; src: string; alt: string };
export type Vehicle = {
  id: number;
  slug: string;
  brand: string;
  model: string;
  year: number;
  category: string;
  transmission: string;
  seats: number;
  fuelType: string | null;
  dailyRate: number;
  deposit: number;
  summary: string;
  description: string;
  features: string[];
  isAvailable: boolean;
  isFeatured: boolean;
  seoTitle: string | null;
  seoDescription: string | null;
  archivedAt: Date | null;
  images: VehicleImage[];
  updatedAt: Date;
};

type Row = {
  id: string; slug: string; brand: string; model: string; year: number; category: string; transmission: string;
  seats: number; fuel_type: string | null; daily_rate: number; deposit: number; summary: string; description: string;
  features: string[]; is_available: boolean; is_featured: boolean; seo_title: string | null; seo_description: string | null;
  archived_at: Date | null; updated_at: Date; images: { id: string; external_url: string | null; alt: string }[] | null;
};

const imageSrc = (img: { id: string | number; external_url: string | null }) => img.external_url ?? `/api/images/${img.id}`;

function mapRow(r: Row): Vehicle {
  const name = `${r.brand} ${r.model}`;
  return {
    id: Number(r.id), slug: r.slug, brand: r.brand, model: r.model, year: r.year, category: r.category,
    transmission: r.transmission, seats: r.seats, fuelType: r.fuel_type, dailyRate: r.daily_rate, deposit: r.deposit,
    summary: r.summary, description: r.description, features: r.features ?? [], isAvailable: r.is_available,
    isFeatured: r.is_featured, seoTitle: r.seo_title, seoDescription: r.seo_description, archivedAt: r.archived_at,
    updatedAt: r.updated_at,
    images: (r.images ?? []).map((i) => ({ id: Number(i.id), src: imageSrc(i), alt: i.alt || `${r.year} ${name}` })),
  };
}

const imagesJson = () => sql()`
  COALESCE((SELECT json_agg(json_build_object('id', vi.id, 'external_url', vi.external_url, 'alt', vi.alt) ORDER BY vi.sort_order, vi.id)
            FROM vehicle_images vi WHERE vi.vehicle_id = v.id), '[]'::json) AS images`;

export type FleetFilters = {
  q?: string;
  category?: string;
  transmission?: string;
  availableOnly?: boolean;
  sort?: "price-asc" | "price-desc" | "newest" | "featured";
};

const SORTS = {
  "price-asc": "v.daily_rate ASC, v.id ASC",
  "price-desc": "v.daily_rate DESC, v.id ASC",
  newest: "v.year DESC, v.id DESC",
  featured: "v.is_featured DESC, v.daily_rate ASC, v.id ASC",
} as const;

export async function listVehicles(f: FleetFilters = {}): Promise<Vehicle[]> {
  const db = sql();
  const q = f.q?.trim().slice(0, 80);
  const like = q ? `%${q.replace(/[%_\\]/g, (c) => `\\${c}`)}%` : null;
  const order = SORTS[f.sort ?? "featured"] ?? SORTS.featured;
  const rows = await db<Row[]>`
    SELECT v.*, ${imagesJson()} FROM vehicles v
    WHERE v.archived_at IS NULL
      ${like ? db`AND (v.brand ILIKE ${like} OR v.model ILIKE ${like} OR (v.brand || ' ' || v.model) ILIKE ${like})` : db``}
      ${f.category ? db`AND v.category = ${f.category}::vehicle_category` : db``}
      ${f.transmission ? db`AND v.transmission = ${f.transmission}::transmission` : db``}
      ${f.availableOnly ? db`AND v.is_available` : db``}
    ORDER BY ${db.unsafe(order)}`;
  return rows.map(mapRow);
}

export async function listCategoriesInStock(): Promise<{ category: string; count: number; fromRate: number }[]> {
  const rows = await sql()<{ category: string; count: string; from_rate: number }[]>`
    SELECT category, count(*) AS count, min(daily_rate) AS from_rate FROM vehicles
    WHERE archived_at IS NULL GROUP BY category ORDER BY min(daily_rate)`;
  return rows.map((r) => ({ category: r.category, count: Number(r.count), fromRate: r.from_rate }));
}

export async function getVehicleBySlug(slug: string, includeArchived = false): Promise<Vehicle | null> {
  const rows = await sql()<Row[]>`
    SELECT v.*, ${imagesJson()} FROM vehicles v
    WHERE v.slug = ${slug} ${includeArchived ? sql()`` : sql()`AND v.archived_at IS NULL`}`;
  return rows[0] ? mapRow(rows[0]) : null;
}

export async function getVehicleById(id: number): Promise<Vehicle | null> {
  const rows = await sql()<Row[]>`SELECT v.*, ${imagesJson()} FROM vehicles v WHERE v.id = ${id}`;
  return rows[0] ? mapRow(rows[0]) : null;
}

export async function listAllVehiclesForAdmin(includeArchived: boolean): Promise<Vehicle[]> {
  const rows = await sql()<Row[]>`
    SELECT v.*, ${imagesJson()} FROM vehicles v
    ${includeArchived ? sql()`` : sql()`WHERE v.archived_at IS NULL`}
    ORDER BY v.archived_at NULLS FIRST, v.brand, v.model`;
  return rows.map(mapRow);
}

function cols(v: VehicleInput) {
  return {
    slug: v.slug, brand: v.brand, model: v.model, year: v.year, category: v.category, transmission: v.transmission,
    seats: v.seats, fuel_type: v.fuelType || null, daily_rate: v.dailyRate, deposit: v.deposit, summary: v.summary,
    description: v.description, features: sql().json(v.features), is_available: v.isAvailable, is_featured: v.isFeatured,
    seo_title: v.seoTitle || null, seo_description: v.seoDescription || null,
  };
}

export async function createVehicle(v: VehicleInput): Promise<number> {
  const rows = await sql()<{ id: string }[]>`INSERT INTO vehicles ${sql()(cols(v))} RETURNING id`;
  return Number(rows[0].id);
}

export async function updateVehicle(id: number, v: VehicleInput) {
  await sql()`UPDATE vehicles SET ${sql()(cols(v))}, updated_at = now() WHERE id = ${id}`;
}

export async function setArchived(id: number, archived: boolean) {
  await sql()`UPDATE vehicles SET archived_at = ${archived ? sql()`now()` : null}, updated_at = now() WHERE id = ${id}`;
}

/** Hard delete only when the car has never been booked; otherwise it must be archived to keep booking history. */
export async function deleteVehicleIfUnused(id: number): Promise<"deleted" | "has_bookings"> {
  return sql().begin(async (tx) => {
    const [{ n }] = await tx<{ n: string }[]>`SELECT count(*) AS n FROM bookings WHERE vehicle_id = ${id}`;
    if (Number(n) > 0) return "has_bookings" as const;
    await tx`DELETE FROM vehicles WHERE id = ${id}`;
    return "deleted" as const;
  });
}

export async function addUploadedImage(vehicleId: number, data: Buffer, mime: string, alt: string) {
  await sql()`
    INSERT INTO vehicle_images (vehicle_id, data, mime_type, alt, sort_order)
    VALUES (${vehicleId}, ${data}, ${mime}, ${alt}, COALESCE((SELECT max(sort_order) + 1 FROM vehicle_images WHERE vehicle_id = ${vehicleId}), 0))`;
}

export async function addExternalImage(vehicleId: number, url: string, alt: string) {
  await sql()`
    INSERT INTO vehicle_images (vehicle_id, external_url, alt, sort_order)
    VALUES (${vehicleId}, ${url}, ${alt}, COALESCE((SELECT max(sort_order) + 1 FROM vehicle_images WHERE vehicle_id = ${vehicleId}), 0))`;
}

export async function deleteImage(vehicleId: number, imageId: number) {
  await sql()`DELETE FROM vehicle_images WHERE id = ${imageId} AND vehicle_id = ${vehicleId}`;
}

export async function moveImageFirst(vehicleId: number, imageId: number) {
  await sql()`UPDATE vehicle_images SET sort_order = CASE WHEN id = ${imageId} THEN -1 ELSE sort_order END WHERE vehicle_id = ${vehicleId}`;
  await sql()`
    UPDATE vehicle_images vi SET sort_order = r.rn FROM (
      SELECT id, row_number() OVER (ORDER BY sort_order, id) - 1 AS rn FROM vehicle_images WHERE vehicle_id = ${vehicleId}
    ) r WHERE vi.id = r.id`;
}

export async function getImageData(id: number): Promise<{ data: Buffer; mime: string } | null> {
  const rows = await sql()<{ data: Buffer | null; mime_type: string | null }[]>`SELECT data, mime_type FROM vehicle_images WHERE id = ${id}`;
  if (!rows[0]?.data || !rows[0].mime_type) return null;
  return { data: rows[0].data, mime: rows[0].mime_type };
}
